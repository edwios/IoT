#ifndef __DK_RFM_h__
#define __DK_RFM_h__

#include "DK_PIC16_App.h"

void RFM22B_Running(u8 mode,u8 WorkStatus,u8 ParaChangeFlag,u8 *TxFlag,u8 *RxFlag,u8 *RSSI);

#endif







